from xml.etree.ElementTree import parse
from elasticsearch import helpers
from datetime import datetime
import elasticsearch
import json
import pandas as pd

import time


class SnortFlow():

	def __init__(self):

		tree 				= parse("snort_rules.xml")
		self.xml_root 		= tree.getroot()
		self.snort_alerts 	= ""
		self.es_client 		= ""
		self.snort_last_ts	= ""

	def connect_elasticsearch(self):
		
		es = elasticsearch.Elasticsearch("localhost:9200")

		if es.ping():
			self.es_client = es
			print "#" * 80
			print "[*] Elasticsearch Connected"

			# get all alerts from es ( initialization )
			print "[*] Get All Snort Alerts from Elasticsearch"
			docs = es.search(index = 'snort-*', body={"query":{"match_all":{}},\
				"sort":{"@timestamp":{"order":"desc"}}}, 
			scroll = '2m',
			size = 1000)
			
			num_docs = docs['hits']['total']
			self.snort_alerts = docs
			_timestamp = docs['hits']['hits'][0]['_source']['@timestamp'].split('.')[0]
			self.snort_last_ts = time.mktime(datetime.strptime(_timestamp, '%Y-%m-%dT%H:%M:%S').timetuple())

			print "[*] Total %d documents from snort_alerts" % num_docs
			print "[*] Snort-* Last Update time : ", _timestamp
			print "#" * 80

		else:
			print "[x] Elasticsearch Connection Error"


	def insert_doc(self, lst, src_ip, dst_ip, id):

		es_client = self.es_client
		ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

		url = '/corr-snort/doc/' + str(id)
		body = '''
		{
			"src_ip":"%s",
			"dst_ip":"%s",
			"high":%d,
			"medium":%d,
			"low":%d,
			"src_cnt":%d,
			"dst_cnt":%d,
			"last_update":"%s"
		}
		''' % (src_ip, dst_ip, lst[0], lst[1], lst[2], lst[3], lst[4], ts)

		res = es_client.transport.perform_request(method='POST', url=url, body=body)

		if res['_shards']['successful'] == 1:
			print "[*] Inserted New Document -", src_ip, dst_ip
		else:
			print "[X] Error - could not insert the doc"

		return es_client


	def update_doc(self, lst, src_ip, dst_ip, doc_id):

		es_client = self.es_client
		ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

		url = '/corr-snort/doc/' + str(doc_id) + '/_update'
		body = '''
			{ "script" : "ctx._source.high += %d; ctx._source.medium += %d; ctx._source.low += %d; ctx._source.src_cnt += %d; ctx._source.dst_cnt += %d; ctx._source.last_update = '%s'"}
		''' % (lst[0], lst[1], lst[2], lst[3], lst[4], ts)

		res = es_client.update(index='corr-snort', doc_type='doc', id=doc_id, body=body)
		if res['_shards']['successful'] == 1:
			print "[*] Updated -", src_ip, dst_ip, lst
		else:
			print "[X] Error - could not update the doc"


	def corr_flow(self):

		snort_docs	= self.snort_alerts
		scroll_id 	= snort_docs['_scroll_id']
		xml_root	= self.xml_root
		es 			= self.es_client
		prior_dic 	= {'1':"high", '2':"medium", '3':"low"}
		total_docs	= 0

		lst = [0,0,0,0,0] # high, medium, low, src_cnt, dst_cnt

		try:
			create = es.indices.create(index='corr-snort')
		except:
			corr_docs = es.search(index= 'corr-snort', body={"query":{"match_all":{}},\
			"sort":{"last_update.keyword":{"order":"desc"}}})
			corr_ts = corr_docs['hits']['hits'][0]['_source']['last_update']
			print "[*] Total Documents in corr-snort index : ", corr_docs['hits']['total']
			print "[*] corr-* Last Update time: ", corr_ts
			corr_ts = time.mktime(datetime.strptime(corr_ts, '%Y-%m-%d %H:%M:%S').timetuple())

			if corr_ts > self.snort_last_ts:
				print "[x] There is no new data to update"
				cp = elasticsearch.ConnectionPool([(x, {}) for x in range(100)])
				
				cp.mark_dead(cp.get_connection())
				print 
				return 

		num_docs = snort_docs['hits']['total']

		while num_docs > 0:

			num_docs = len(snort_docs['hits']['hits'])
			print "- [*] {0} docs retrieved".format(num_docs)
			time.sleep(1)

			for doc in snort_docs['hits']['hits']:

				lst = [0,0,0,0,0]

				src_ip = doc['_source']['src_ip'] 
				dst_ip = doc['_source']['dest_ip'] 
				prior = doc['_source']['priority']
				_class = doc['_source']['class']
				lst[int(prior)-1] = 1

				query = '''
					{
					    "query" : {
					      "bool" : {
					        "must" : [
					            {"term": { "src_ip" : "%s" }},
					            {"term": { "dst_ip" : "%s" }}
					          ] 
					      }
					    }
					}
				''' % (src_ip, dst_ip)

				corr_docs = es.search(index='corr-snort', body=query)
				num_docs = corr_docs['hits']['total']

				if num_docs > 0:
					doc_id = corr_docs['hits']['hits'][0]['_id']
					print "[-] Found a matched doc" 

				for element in xml_root.findall(prior_dic[prior]):
					if element.findtext("class") == _class:
						if element.findtext("src_ip") == '1':
							lst[3] += 1
						elif element.findtext("dst_ip") == '1':
							lst[4] += 1

				if num_docs == 0: 	# if there is no data
					_id = total_docs
					total_docs += 1
					es = self.insert_doc(lst, src_ip, dst_ip, _id)
				else:				# if data exists
					_id = doc_id
					self.update_doc(lst, src_ip, dst_ip, _id)				

			snort_docs = es.scroll(scroll_id = scroll_id, scroll='2m')
			num_docs = len(snort_docs['hits']['hits'])



		
if __name__ == "__main__":

	sf = SnortFlow()
	sf.connect_elasticsearch()
	sf.corr_flow()