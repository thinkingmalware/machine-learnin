import elasticsearch
import time
import pandas as pd
import numpy as np

from datetime import datetime
from sklearn.neighbors import LocalOutlierFactor

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

class AnomalyDetector():

	def __init__(self):
		self.nn 			= 15
		self.df 			= pd.read_csv('features.csv')
		self.es_client 		= ""
		self.nor_per 		= 0.3
		self.ano_per 		= 0.05

	def connect_elasticsearch(self):
		
		es = elasticsearch.Elasticsearch("localhost:9200")

		if es.ping():
			self.es_client = es
			print "#" * 80
			print "[*] Elasticsearch Connected"
		else:
			print "[x] Elasticsearch Connection Error"

	def insert_doc(self, row, id):

		es = self.es_client

		url = '/anomaly-score/doc/' + str(id)
		body = '''
		{
			"last_update":"%s",
			"src_ip":"%s",
			"src_port":"%s",
			"dst_ip":"%s",
			"dst_port":"%s",
			"lof_score":%d,
			"check":%d
		}
		''' % (row['ts'], str(row['src_ip']), row['src_port'], str(row['dst_ip']), row['dst_port'], row['lof_score'], row['check'])

		es.indices.refresh(index= 'anomaly-score')
		res = es.transport.perform_request(method='POST', url=url, body=body)
		es.indices.refresh(index= 'anomaly-score')

		if res['_shards']['successful'] == 1:
			print "+",
		else:
			print "[X] Error - could not insert the doc"

	def update_doc(self, row, doc_id):

		es = self.es_client
		ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

		url = '/anomaly-score/doc/' + str(doc_id) + '/_update'
		body = '''
			{ "script" : "ctx._source.lof_score += %d; ctx._source.check == %d"}
		''' % (row['lof_score'], row['check'])

		res = es.update(index='anomaly-score', doc_type='doc', id=doc_id, body=body)

		if res['_shards']['successful'] == 1:
			print "#",
		else:
			print "[X] Error - could not update the doc"

	def push_elastic(self):

		es = self.es_client
		df = self.df
		row = dict()

		ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		total_docs = 1

		try:
			create = es.indices.create(index='anomaly-score')
		except:
			pass

		for idx, row in df.iterrows():

			row['src_ip']		= df.loc[idx,'src_ip']
			row['src_port']		= df.loc[idx,'src_port']
			row['dst_ip']		= df.loc[idx,'dst_ip']
			row['dst_port']		= df.loc[idx,'dst_port']
			row['lof_score'] 	= df.loc[idx,'lof_score']
			row['check']		= df.loc[idx, 'check']
			row['ts']			= ts

			query = '''
				{
				    "query" : {
				      "bool" : {
				        "must" : [
				            {"term": { "src_ip" : "%s" }},
				            {"term": { "src_port" : "%s" }},
				            {"term": { "dst_ip" : "%s" }},
				            {"term": { "dst_port" : "%s" }}
				          ] 
				      }
				    }
				}
			''' % (row['src_ip'], row['src_port'], row['dst_ip'], row['dst_port'])

			es.indices.refresh(index= 'anomaly-score')
			anom_docs = es.search(index= 'anomaly-score', body=query)
			es.indices.refresh(index= 'anomaly-score')

			num_docs = anom_docs['hits']['total']

			if num_docs == 0: 	# if there is no data
				_id = total_docs
				total_docs += 1
				self.insert_doc(row, _id)
			else:
				doc_id = anom_docs['hits']['hits'][0]['_id'] # if data exists
				_id = doc_id
				self.update_doc(row, _id)

	def get_lofscore(self):

		nor_per = self.nor_per
		ano_per = self.ano_per
		nn = self.nn
		df = self.df[['orig_bytes', 'resp_bytes', 'orig_packets', 'resp_packets', \
		'duration', 'is_inbound', 'unique_dst', 'unique_src', 'same_dst', 'same_src', \
		'high', 'medium', 'low', 'snort_src_cnt', 'snort_dst_cnt', 'lof_score']]

		clf = LocalOutlierFactor(n_neighbors=nn, contamination=00.1)
		y_pred = clf.fit_predict(df)

		self.df['lof_score'] = clf.negative_outlier_factor_
		self.df = self.df.sort_values(by=['lof_score'], ascending=False)
		self.df.to_csv('anomal_features.csv', index=False)

		total = len(self.df)
		nor_idx = len(self.df[self.df['lof_score'] < -2])
		ano_idx = int(round(total * ano_per))

		nor_lst = np.empty(nor_idx)
		ano_lst = np.empty(ano_idx)
		nor_lst.fill(10)
		ano_lst.fill(-10)
		mid_lst = np.empty(total - nor_idx - ano_idx)
		mid_lst = np.zeros(len(mid_lst))

		score = np.concatenate((nor_lst, mid_lst, ano_lst), axis=0)	
		check = np.zeros(total)
		self.df['lof_score'] = score
		self.df['check'] = check

		self.push_elastic()


AD = AnomalyDetector()
AD.connect_elasticsearch()
AD.get_lofscore()


