from extract_features import GetDocs
from snort_flow import SnortFlow

from apscheduler.jobstores.base import JobLookupError
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime, date
import time
import sys
import logging

log = logging.getLogger('apscheduler.executors.default')
log.setLevel(logging.INFO)  # DEBUG

fmt = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
h = logging.StreamHandler()
h.setFormatter(fmt)
log.addHandler(h)


class Scheduler:
	def __init__(self, log_file):

		today = date.today()
		self.bgsched = BackgroundScheduler()
		self.bgsched.start()
		self.job_id = ''
		self.log = log_file
		self.day = str(today.year) + "." + str(today.month).rjust(2, '0') + "." + str(today.day-1)

	def __del__(self):
		self.shutdown()

	def shutdown(self):
		self.bgsched.shutdown()

	def kill_scheduler(self, job_id):
		try:
			self.bgsched.remove_job(job_id)
		except JobLookupError as err:
			print("Fail to stop Scheduler: {err}".format(err=err))
			return

	def write_log(self, message):

		msg = '''
{job}
		'''.format(job=message)
		self.log.write(msg)


	def analyze_snort(self):

		bold_line = "=" * 80
		norm_line = '-' * 80
		job_start = "[" + datetime.now().isoformat() + "] Snort Flow Job Started (job_id = 1)"

		self.write_log(job_start)
		print "\n", bold_line, job_start, "\n", norm_line

		sf = SnortFlow(self.day)
		sf.connect_elasticsearch()
		sf.corr_flow()

		job_completed = "[" + datetime.now().isoformat() + "] Snort Flow Job Completed"
		print norm_line, job_completed, "\n", bold_line

		self.write_log(job_completed)

	def process_features(self):

		bold_line = "=" * 80
		norm_line = '-' * 80
		job_start = "[" + datetime.now().isoformat() + "] Process Features Job Started (job_id = 1)"

		self.write_log(job_start)
		print "\n", bold_line, job_start, "\n", norm_line

		feature = GetDocs(self.day)
		feature.connect_elasticsearch()
		feature.extract()

		job_completed = "[" + datetime.now().isoformat() + "] Process Features Job Completed"
		print norm_line, job_completed, "\n", bold_line
		self.write_log(job_completed)


	def scheduler(self, type, job_id):
		if type == 'Snort Flow':
			self.bgsched.add_job(self.analyze_snort, 'interval', minutes=60, id=job_id)
		elif type == 'Extract Features':
			self.bgsched.add_job(self.process_features, 'cron', day_of_week='mon-fri',  day=1, id=job_id)

class Switcher(object):

	def __init__(self, scheduler):
		self.sched = scheduler

	def run_command(self, command, job_id):
		method_name = command
		method = getattr(self, method_name, lambda *args: "Invalid Command")
		# Call the method as we return it
		return method(job_id)
 

	def kill(self, job_id):
		self.sched.kill_scheduler(job_id)

	def deploy(self, job_id):
		self.sched.kill_scheduler('1')
		self.sched.kill_scheduler('2')

		self.sched.bgsched.add_job(self.sched.analyze_snort, 'interval', minutes=30, id='1')
		self.sched.bgsched.add_job(self.sched.process_features, 'cron', day_of_week='mon-fri', hour=1, id='2')


	def train(self, job_id):
		self.sched.kill_scheduler('1')
		self.sched.kill_scheduler('2')
		
		self.sched.scheduler('Snort Flow', "1")
		self.sched.scheduler('Extract Features', "2")

	def quit(self, job_id):
		self.sched.shutdown()	
		sys.exit()
		

if __name__ == '__main__':

	log_file = open("message.log", "w")
	bold_line = "#" * 80
	log_file.write(bold_line + "\n" + datetime.now().isoformat() + "- ANOMALY DETECTOR LOG\n" + bold_line)

	scheduler = Scheduler(log_file)
	scheduler.scheduler('Snort Flow', "1")
	scheduler.scheduler('Extract Features', "2")

	switcher = Switcher(scheduler)
	job_id = 0


	print "#" * 80
	print "- Welcome to BJ Anomaly Detector by nababora"
	print "- command: deploy, kill, quit, train"
	print "#" * 80

	while True:
		cmd = raw_input('Command # ')
		
		if cmd == "kill":
			job_id = raw_input("Input a job id you want to kill: ")

		switcher.run_command(cmd, job_id)

		time.sleep(1) 

