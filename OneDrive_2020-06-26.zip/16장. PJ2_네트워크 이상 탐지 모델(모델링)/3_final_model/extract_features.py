import elasticsearch
import json
import time
from datetime import datetime

import pandas as pd
import numpy as np

from anomaly_detector import AnomalyDetector


class GetDocs():

	def __init__(self, day):

		cols = ["timestamp","src_ip","src_port","dst_ip","dst_port","orig_bytes" \
		,"resp_bytes","orig_packets","resp_packets", "duration", "is_inbound", "unique_dst", \
		"unique_src", "same_dst", "same_src", "high", "medium", "low", \
		"snort_src_cnt", "snort_dst_cnt", "lof_score", "anomal_score"]

		self.es_client = ""
		self.internals = ["20.20.20.10"]
		self.time_window = 10 # not used in this example
		self.conn_window = 100
		self.df = pd.DataFrame(columns=cols)
		self.bro_index = "bro_conn-" + day

	def connect_elasticsearch(self):
		es = elasticsearch.Elasticsearch("localhost:9200")

		if es.ping():
			self.es_client = es
			print "#" * 80
			print "[*] Elasticsearch Connected (EF) "
			print "#" * 80
		else:
			print "[x] Elasticsearch Connection Error (EF)"

	def extract(self):
		print "[+] Retreiving documents from elasticsearch with query"
		i = 0
		cnt = 0
		df = self.df
		es = self.es_client
		inter = self.internals

		body = '''
		{
		  "query":
		  {
		    "bool":
		      { "must_not": 
		      	[
			        {"regexp":{"id_resp_host":"f.*"}}		        
			    ]
		  	  }
			},
		  "sort": { "@timestamp": { "order": "desc" }}
		}
		'''
		docs = es.search(index = self.bro_index, body = body, scroll = '5m', size = 1000) 


		scroll_id = docs['_scroll_id']
		num_docs = docs['hits']['total']
		print "[*] Total %d documents will be retrieved" % num_docs

		while num_docs > 0:

			num_docs = len(docs['hits']['hits'])
			cnt += num_docs
			print "- [*] {0} docs retrieved".format(cnt)


			for doc in docs['hits']['hits']:
				
				ts = doc['_source']['@timestamp'].split('.')[0]
				ts = time.mktime(datetime.strptime(ts, '%Y-%m-%dT%H:%M:%S').timetuple())

				if doc['_source']['id_orig_host'] not in inter and doc['_source']['id_resp_host'] in inter:
					is_inbound = 1
				else:
					is_inbound = 0

				pkt = [ts, doc['_source']['id_orig_host'],doc['_source']['id_orig_port'],doc['_source']['id_resp_host'], \
				doc['_source']['id_resp_port'],doc['_source']['orig_bytes'],doc['_source']['resp_bytes'],doc['_source']['orig_pkts'], \
				doc['_source']['resp_pkts'],doc['_source']['duration'],is_inbound,0,0,0,0,0,0,0,0,0,0,0]

				pkt = self.match_snort(pkt)

				df.loc[i] = pkt
				i += 1

			docs = es.scroll(scroll_id = scroll_id, scroll= '5m')
			num_docs = len(docs['hits']['hits'])

		df = self.flow_features(df)
		self.run_anomaly(df)


	def run_anomaly(self, df):

		AD = AnomalyDetector(df)
		AD.connect_elasticsearch()
		AD.get_lofscore()


	def match_snort(self, lst):
		
		es = self.es_client

		src_ip = lst[1]
		dst_ip = lst[3]

		query = '''
				{
				    "query" : {
				      "bool" : {
				        "must" : [
				            {"term": { "src_ip" : "%s" }},
				            {"term": { "dst_ip" : "%s" }}
				          ] 
				      }
				    }
				}
			''' % (src_ip, dst_ip)

		corr_docs = es.search(index= 'corr-snort', body=query)
		
		try:
			lst[15] = corr_docs['hits']['hits'][0]['_source']['high']
			lst[16] = corr_docs['hits']['hits'][0]['_source']['medium']
			lst[17] = corr_docs['hits']['hits'][0]['_source']['low']
			lst[18] = corr_docs['hits']['hits'][0]['_source']['src_cnt']
			lst[19] = corr_docs['hits']['hits'][0]['_source']['dst_cnt']
		except:
			pass

		return lst
	

	def flow_features(self, df):

		print "[+] Extracting Derived Features. It will take some time."
		c_window = self.conn_window

		for idx, row in df.iterrows():

			uniq_dst_dic = dict()
			uniq_src_dic = dict()
			same_dst_port = 0
			same_src_port = 0
			row_i = df.loc[idx]

			if idx == (df.shape[0]-c_window):
				break

			for j in range (idx, idx+c_window):
				row_j = df.loc[j]

				# unique_inside_dst        
				if row_j['is_inbound']:
					try:
						uniq_dst_dic[row_j['dst_ip']] += 1
					except:
						uniq_dst_dic[row_j['dst_ip']] = 1

				# same_dst_port_rate
				if row_i['dst_port'] == row_j['dst_port']:
					same_dst_port += 1

				# unique_inside_src
				if row_j['is_inbound']:
					try:
						uniq_src_dic[row_j['src_ip']] += 1
					except:
						uniq_src_dic[row_j['src_ip']] = 1

				# same_src_port_rate
				if row_i['src_port'] == row_j['src_port']:
					same_src_port += 1         

			df.loc[idx,'unique_dst'] = len(uniq_dst_dic)
			df.loc[idx,'unique_src'] = len(uniq_src_dic)
			df.loc[idx,'same_dst'] = same_dst_port
			df.loc[idx,'same_src'] = same_src_port

		print "[*] Done"
		return df


